const { Client } = require('pg');

exports.handler = async (event) => {
  const scoutId = event.queryStringParameters?.scoutId || (event.body && JSON.parse(event.body).scoutId);
  if (!scoutId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: 'Missing scoutId' }),
      headers: { 'Access-Control-Allow-Origin': '*' }
    };
  }

  const client = new Client({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }
  });

  await client.connect();

  // Get all unique athlete and coach IDs viewed by this scout
  const res = await client.query(
    `SELECT DISTINCT u.id, u.name, u.profile_picture_url, u.role
     FROM notifications n
     JOIN users u ON u.id = n.to_user_id
     WHERE n.type = 'profile_view'
       AND n.from_user_id = $1
       AND (u.role = 'athlete' OR u.role = 'coach')
     ORDER BY n.created_at DESC`,
    [scoutId]
  );

  await client.end();

  // Split into athletes and coaches
  const athletes = res.rows.filter(u => u.role === 'athlete');
  const coaches = res.rows.filter(u => u.role === 'coach');

  return {
    statusCode: 200,
    body: JSON.stringify({ athletes, coaches }),
    headers: { 'Access-Control-Allow-Origin': '*' }
  };
};