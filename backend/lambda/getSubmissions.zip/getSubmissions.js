const { Client } = require('pg');

exports.handler = async (event) => {
  const claims = event?.requestContext?.authorizer?.jwt?.claims;
  const groups = claims?.["cognito:groups"] || [];
  const customRole = claims?.["custom:role"] || "";
  const coachId = claims?.sub;  // Assuming sub is the coach ID

  const client = new Client({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();

    let query, values;
    if (groups.includes("coaches") || customRole === "coach") {
      query = `
        SELECT s.*, c.title AS challenge_title
        FROM challenge_submissions s
        JOIN challenges c ON s.challenge_id = c.id
        WHERE c.coach_id = $1
        ORDER BY s.submitted_at DESC
      `;
      values = [coachId];
    } else if (groups.includes("athletes") || customRole === "athlete") {
      query = `
        SELECT * FROM challenge_submissions
        ORDER BY submitted_at DESC
      `;
      values = [];
    } else {
      return {
        statusCode: 403,
        body: JSON.stringify({ message: "Forbidden: Invalid role" })
      };
    }

    const res = await client.query(query, values);
    await client.end();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(res.rows)
    };

  } catch (err) {
    console.error('DB error:', err);
    await client.end();
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error fetching submissions', error: err.message })
    };
  }
};
