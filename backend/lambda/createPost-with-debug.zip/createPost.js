const { Client } = require('pg');
const AWS = require('aws-sdk');
const s3 = new AWS.S3();

const S3_BUCKET_NAME = process.env.POST_IMAGES_BUCKET_NAME || 'findplayer-post-images';
const REGION = process.env.REGION || 'us-east-1';

exports.handler = async (event) => {
  // Handle OPTIONS requests for CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
      },
      body: JSON.stringify({})
    };
  }

  try {
    console.log('Parsing body...');
    const body = JSON.parse(event.body);
    const { userId, content, imageBase64, imageContentType } = body;
    console.log('Body parsed:', { userId, content, imageBase64: imageBase64 ? 'present' : 'missing', imageContentType });

    if (!userId || !content) {
      return {
        statusCode: 400,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Headers': 'Content-Type',
          'Access-Control-Allow-Methods': 'POST, OPTIONS'
        },
        body: JSON.stringify({ message: 'userId and content are required' })
      };
    }

    let imageUrl = null;

    // Handle image upload if provided
    if (imageBase64 && imageContentType && S3_BUCKET_NAME) {
      console.log('Starting image upload process...');
      console.log('S3_BUCKET_NAME:', S3_BUCKET_NAME);
      console.log('REGION:', REGION);
      
      try {
        // Check if S3 bucket exists
        try {
          await s3.headBucket({ Bucket: S3_BUCKET_NAME }).promise();
          console.log('S3 bucket exists and is accessible');
        } catch (bucketError) {
          console.error('S3 bucket check failed:', bucketError);
          throw new Error(`S3 bucket ${S3_BUCKET_NAME} is not accessible: ${bucketError.message}`);
        }

        // Validate image size (max 2MB)
        const imageBuffer = Buffer.from(imageBase64, 'base64');
        console.log('Image buffer size:', imageBuffer.length, 'bytes');
        
        if (imageBuffer.length > 2 * 1024 * 1024) {
          return {
            statusCode: 400,
            headers: { 
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Headers': 'Content-Type',
              'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({ message: "Image file size exceeds 2MB." })
          };
        }

        // Validate image type
        if (!imageContentType.startsWith('image/')) {
          return {
            statusCode: 400,
            headers: { 
              'Access-Control-Allow-Origin': '*',
              'Access-Control-Allow-Headers': 'Content-Type',
              'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            body: JSON.stringify({ message: "Only image files are allowed." })
          };
        }

        // Generate unique file name
        const fileExtension = imageContentType.split('/')[1] || 'jpeg';
        const s3Key = `post-images/${userId}-${Date.now()}.${fileExtension}`;
        console.log('Generated S3 key:', s3Key);
        
        const s3UploadParams = {
          Bucket: S3_BUCKET_NAME,
          Key: s3Key,
          Body: imageBuffer,
          ContentType: imageContentType,
          ACL: 'public-read' // Make images publicly accessible
        };
        
        console.log('Uploading to S3 with params:', { Bucket: s3UploadParams.Bucket, Key: s3UploadParams.Key, ContentType: s3UploadParams.ContentType });
        await s3.upload(s3UploadParams).promise();
        imageUrl = `https://${S3_BUCKET_NAME}.s3.${REGION}.amazonaws.com/${s3Key}`;
        
        console.log(`Post image uploaded to S3: ${imageUrl}`);
      } catch (err) {
        console.error("Error uploading post image to S3:", err);
        console.error("Error details:", JSON.stringify(err, null, 2));
        return {
          statusCode: 500,
          headers: { 
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Methods': 'POST, OPTIONS'
          },
          body: JSON.stringify({ message: "Failed to upload image. Please try again." })
        };
      }
    } else {
      console.log('Image upload skipped - conditions not met:');
      console.log('- imageBase64 present:', !!imageBase64);
      console.log('- imageContentType present:', !!imageContentType);
      console.log('- S3_BUCKET_NAME present:', !!S3_BUCKET_NAME);
    }

    console.log('Connecting to database...');
    const client = new Client({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      ssl: { rejectUnauthorized: false }
    });

    await client.connect();
    console.log('Database connected');

    // Insert the post
    const insertQuery = `
      INSERT INTO posts (user_id, content, image_url)
      VALUES ($1, $2, $3)
      RETURNING id, user_id, content, image_url, created_at
    `;
    
    console.log('Executing query...');
    const result = await client.query(insertQuery, [userId, content, imageUrl]);
    console.log('Query executed, result:', result.rows[0]);
    
    await client.end();
    console.log('Database connection closed');

    return {
      statusCode: 201,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: JSON.stringify({
        message: 'Post created successfully',
        post: result.rows[0]
      })
    };

  } catch (error) {
    console.error('Error creating post:', error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: JSON.stringify({ message: 'Internal server error' })
    };
  }
}; 