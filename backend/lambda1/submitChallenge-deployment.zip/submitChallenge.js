const { Client } = require('pg');
const AWS = require('aws-sdk');

const sns = new AWS.SNS({ region: process.env.AWS_REGION || 'us-east-1' });

exports.handler = async (event) => {
  // Handle OPTIONS requests for CORS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Max-Age': '86400'
      },
      body: ''
    };
  }

  const claims = event?.requestContext?.authorizer?.jwt?.claims;
  const groups = claims?.["cognito:groups"] || [];
  const customRole = claims?.["custom:role"] || "";

  if (!groups.includes("athletes") && customRole !== "athlete") {
    return {
      statusCode: 403,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: "Forbidden: Only athletes can submit challenges" })
    };
  }

  const challengeId = event.pathParameters.id;
  const body = JSON.parse(event.body);
  const { video_url } = body;

  const athleteId = claims?.sub;
  const athleteName = claims?.given_name || claims?.name || "Unknown";

  if (!athleteId) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: "User ID not found in token" })
    };
  }

  const client = new Client({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();

    // Check if user exists
    const userResult = await client.query(
      'SELECT is_premium_member FROM users WHERE id = $1',
      [athleteId]
    );
    
    if (userResult.rows.length === 0) {
      await client.end();
      return {
        statusCode: 404,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: 'Athlete not found' })
      };
    }

    const existingSubmission = await client.query(
      `SELECT * FROM challenge_submissions 
       WHERE challenge_id = $1 AND athlete_id = $2`,
      [challengeId, athleteId]
    );

    if (existingSubmission.rows.length > 0) {
      await client.end();
      return {
        statusCode: 409,
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          message: 'You have already submitted a video for this challenge',
          submission: existingSubmission.rows[0]
        })
      };
    }

    // Insert the submission
    const result = await client.query(
      `INSERT INTO challenge_submissions (challenge_id, athlete_id, athlete_name, video_url, status)
       VALUES ($1, $2, $3, $4, 'pending')
       RETURNING *`,
      [challengeId, athleteId, athleteName, video_url]
    );
    const submission = result.rows[0];

    // Fetch coach ID and challenge details for the notification
    const coachRes = await client.query(
      `SELECT c.coach_id, c.title as challenge_title, u.given_name as coach_name 
       FROM challenges c 
       JOIN users u ON c.coach_id = u.id 
       WHERE c.id = $1`,
      [challengeId]
    );
    
    const coachId = coachRes.rows[0]?.coach_id;
    const challengeTitle = coachRes.rows[0]?.challenge_title;
    const coachName = coachRes.rows[0]?.coach_name || 'Coach';

    if (coachId) {
      // Insert notification for coach
      await client.query(
        `INSERT INTO notifications (type, from_user_id, to_user_id, challenge_id, submission_id, is_read, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, NOW())`,
        ['challenge_submission', athleteId, coachId, challengeId, submission.id, false]
      );

      // Send push notification to coach
      try {
        const tokenRes = await client.query(
          'SELECT push_token, push_platform FROM users WHERE id = $1', 
          [coachId]
        );
        
        const pushToken = tokenRes.rows[0]?.push_token;
        const pushPlatform = tokenRes.rows[0]?.push_platform;

        if (pushToken && pushPlatform) {
          console.log(`Sending challenge submission notification to coach ${coachId} on platform ${pushPlatform}`);

          if (pushPlatform === 'android') {
            const message = {
              GCM: JSON.stringify({
                data: {
                  type: 'challenge_submission',
                  title: 'New Challenge Submission',
                  body: `${athleteName} submitted a video for "${challengeTitle}"`,
                  challengeId: challengeId.toString(),
                  submissionId: submission.id.toString(),
                  athleteId: athleteId
                },
                notification: {
                  title: 'New Challenge Submission',
                  body: `${athleteName} submitted a video for "${challengeTitle}"`,
                  icon: 'ic_notification',
                  click_action: 'FLUTTER_NOTIFICATION_CLICK'
                }
              })
            };

            await sns.publish({
              TargetArn: pushToken,
              Message: JSON.stringify(message),
              MessageStructure: 'json'
            }).promise();

            console.log(`Sent Android notification to coach ${coachId}`);
          } else if (pushPlatform === 'ios') {
            const message = {
              APNS: JSON.stringify({
                aps: {
                  alert: {
                    title: 'New Challenge Submission',
                    body: `${athleteName} submitted a video for "${challengeTitle}"`
                  },
                  badge: 1,
                  sound: 'default',
                  category: 'CHALLENGE_SUBMISSION',
                  'mutable-content': 1
                },
                data: {
                  type: 'challenge_submission',
                  challengeId: challengeId.toString(),
                  submissionId: submission.id.toString(),
                  athleteId: athleteId
                }
              })
            };

            await sns.publish({
              TargetArn: pushToken,
              Message: JSON.stringify(message),
              MessageStructure: 'json'
            }).promise();

            console.log(`Sent iOS notification to coach ${coachId}`);
          }
        }
      } catch (error) {
        console.error('Error sending challenge submission push notification:', error);
        // Don't fail the submission if notification fails
      }
    }

    // Update user streak
    const streakRes = await client.query(
      'SELECT current_streak, last_streak_date FROM users WHERE id = $1',
      [athleteId]
    );
    if (streakRes.rowCount > 0) {
      const { current_streak, last_streak_date } = streakRes.rows[0];
      const today = new Date().toISOString().slice(0, 10);
      const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
      let newStreak = 1;
      if (last_streak_date === today) {
        newStreak = current_streak;
      } else if (last_streak_date === yesterday) {
        newStreak = current_streak + 1;
      }
      await client.query(
        'UPDATE users SET current_streak = $1, last_streak_date = $2 WHERE id = $3',
        [newStreak, today, athleteId]
      );
    }

    await client.end();

    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: 'Submission received successfully',
        submission: submission
      }),
    };
  } catch (err) {
    console.error('DB error:', err);
    await client.end();
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: 'Error submitting challenge', error: err.message }),
    };
  }
};