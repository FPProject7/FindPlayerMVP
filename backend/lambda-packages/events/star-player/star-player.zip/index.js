const { Client } = require('pg'); // or your DB client

exports.handler = async (event) => {
  try {
    const { scoutId, athleteId } = JSON.parse(event.body);
    if (!scoutId || !athleteId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing scoutId or athleteId' }) };
    }
    // TODO: Replace with real DB insert
    // await db.query('INSERT INTO starred_players (scout_id, athlete_id, created_at) VALUES ($1, $2, NOW())', [scoutId, athleteId]);
    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}; 