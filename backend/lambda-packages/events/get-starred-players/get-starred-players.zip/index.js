const { Client } = require('pg'); // or your DB client

exports.handler = async (event) => {
  try {
    const scoutId = event.queryStringParameters && event.queryStringParameters.scoutId;
    if (!scoutId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing scoutId' }) };
    }
    // TODO: Replace with real DB select
    // const result = await db.query('SELECT athlete_id FROM starred_players WHERE scout_id = $1', [scoutId]);
    // const starred = result.rows;
    const starred = [
      { athleteId: 1, name: 'Stephan Ziadieh', email: 'stephan@email.com', img: 'https://randomuser.me/api/portraits/men/32.jpg' },
      { athleteId: 2, name: 'Alex Johnson', email: 'alex@email.com', img: 'https://randomuser.me/api/portraits/men/33.jpg' }
    ]; // placeholder
    return { statusCode: 200, body: JSON.stringify({ starred }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}; 