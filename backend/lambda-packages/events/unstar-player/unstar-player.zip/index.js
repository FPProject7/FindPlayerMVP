const { Client } = require('pg'); // or your DB client

exports.handler = async (event) => {
  try {
    const { scoutId, athleteId } = JSON.parse(event.body);
    if (!scoutId || !athleteId) {
      return { statusCode: 400, body: JSON.stringify({ error: 'Missing scoutId or athleteId' }) };
    }
    // TODO: Replace with real DB delete
    // await db.query('DELETE FROM starred_players WHERE scout_id = $1 AND athlete_id = $2', [scoutId, athleteId]);
    return { statusCode: 200, body: JSON.stringify({ success: true }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}; 